All the files contained in this folder are replicas of folders contained in the folder B:\Research\RAWDATA\MEDLINE\2014\Parsers. 
The output from these files is contained in the folder B:\Research\RAWDATA\MEDLINE\2014\Parsed.

The reason for the replicas is that multiple projects use the parsed ouput and it is wasteful for each project to have its own set of parsed files.
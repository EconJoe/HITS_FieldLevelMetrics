# Code_HITS3
Series of Perl scripts and Stata dofiles that parse and process MEDLINE files for the purposes of text mining for a project on High Impact and Transformative Science (HITS).

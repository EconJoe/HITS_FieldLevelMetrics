To obtain the text metrics, run the batch file named batch.bat. This will take several days (maybe longer) to run. It only works on a Windows OS.
To run only the stata dofiles, run the batch file named statabatch.bat. This will only take a day or two.

The Perl scripts are replications of files located in B:\Research\RAWDATA\MEDLINE\2014\Parsers and B:\Research\RAWDATA\MeSH\2014\Parsers
They are also located on GitHub in the repository: https://github.com/EconJoe/medline2014-xmlparsers

Many of the Stata dofiles are replications of files located in B:\Research\RAWDATA\MEDLINE\2014\Processors
They are also located on GitHub in the repository: https://github.com/EconJoe/medline2014-processors

The reason that the above Perl scripts and Stata dofiles are located in multiple locations is that they are used for several projects, and so I wanted them in a single central locations.\
